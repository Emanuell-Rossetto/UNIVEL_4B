package Aulas;

public class HelloWorld {
    public static void main(String[] arg) {
        System.out.println("Ola mundo");
    }
}
